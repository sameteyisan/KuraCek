import 'dart:math';

import 'package:KuraCek/myKuralar.dart';
import 'package:KuraCek/second_screen.dart';
import 'package:KuraCek/sqflite.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

var splitsizString = '';
var splitList = [];
var addList = [];
var selectedList = [];
var _random = Random();
var count = 0;
var digerCount = 0;
var listeler = '';
List<TaskModel> tumHsepsi = [];
TaskModel gonderilen;

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Kura Çek',
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

// ignore: missing_return
Future<bool> _onBackPressed(BuildContext context) {
  FocusScope.of(context).unfocus();
}

class _MyHomePageState extends State<MyHomePage> {
  TextEditingController inputController = TextEditingController();
  TextEditingController kisiInputController = TextEditingController();
  TextEditingController inputKuraAdiController = TextEditingController();
  final GlobalKey<ScaffoldState> _snackbarKey = new GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    final TodoHelper _todoHelper = TodoHelper();

    setState(() {
      addList = addList;
    });
    return Scaffold(
      key: _snackbarKey,
      appBar: AppBar(
        centerTitle: true,
        title: Text('Kura Çek'),
      ),
      floatingActionButtonLocation: addList.length == 0
          ? FloatingActionButtonLocation.endFloat
          : FloatingActionButtonLocation.centerFloat,
      floatingActionButton: addList.length == 0
          ? FlatButton(
              color: Colors.deepOrange,
              onPressed: () async {
                List<TaskModel> list = await _todoHelper.getAllTask();
                savedKuralar = list;
                print(list.length);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyKuralar()),
                );
              },
              child: Text(
                'Kuralarımı Göster',
                style:
                    TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            )
          : Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                FlatButton(
                  color: Colors.deepOrange,
                  onPressed: () async {
                    showDialog<String>(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Container(
                              alignment: Alignment.center,
                              child: Text(
                                'Bir Kura Adı Belirleyiniz.',
                                style: TextStyle(fontSize: 17),
                              ),
                            ),
                            content: Container(
                              height: 100,
                              child: Column(
                                children: [
                                  TextField(
                                    controller: inputKuraAdiController,
                                    maxLength: 12,
                                    onChanged: (value) {},
                                    autofocus: true,
                                    decoration: InputDecoration(
                                      labelText: 'Kura Adı',
                                      suffixIcon: IconButton(
                                        icon: Icon(Icons.clear),
                                        onPressed: () {
                                          inputKuraAdiController.clear();
                                        },
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            actions: [
                              FlatButton(
                                color: Colors.green,
                                onPressed: () {
                                  Navigator.pop(context);
                                  inputKuraAdiController.clear();
                                },
                                child: Text('İptal'),
                              ),
                              FlatButton(
                                color: Colors.deepOrange,
                                onPressed: () {
                                  if (inputKuraAdiController.text.length == 0) {
                                    print('Bir Ad Belirle');
                                  } else {
                                    for (var i = 0; i < addList.length; i++) {
                                      setState(() {
                                        listeler += addList[i] + ', ';
                                      });
                                    }
                                    print(listeler);
                                    gonderilen = TaskModel(
                                        kuraList: listeler,
                                        name: inputKuraAdiController.text);
                                    _todoHelper.insertTask(gonderilen);
                                    setState(() {
                                      listeler = '';
                                      addList.clear();
                                      Navigator.pop(context);
                                      inputKuraAdiController.clear();
                                      _snackbarKey.currentState
                                          .showSnackBar(SnackBar(
                                        backgroundColor: Colors.deepOrange,
                                        content: Row(
                                          children: [
                                            Text(
                                              'Kura Kaydedildi.',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        duration: Duration(seconds: 1),
                                      ));
                                    });
                                  }
                                },
                                child: Text('Belirle'),
                              )
                            ],
                          );
                        });
                  },
                  child: Text(
                    'Kurayı Kaydet',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                ),
                FlatButton(
                  color: Colors.deepOrange,
                  child: Text(
                    'Kura Çekmeyi Başlat',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                  onPressed: () {
                    if (addList.length == 0) {
                      _snackbarKey.currentState.showSnackBar(SnackBar(
                        backgroundColor: Colors.deepOrange,
                        content: Row(
                          children: [
                            Text(
                              'Hiçbir aday girilmedi',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                        duration: Duration(seconds: 1),
                      ));
                    } else {
                      kisiInputController.clear();
                      return showDialog<String>(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: Container(
                                alignment: Alignment.center,
                                child: Text(
                                  '${addList.length} adaydan kaç aday seçilecek ?',
                                  style: TextStyle(fontSize: 17),
                                ),
                              ),
                              content: Container(
                                height: 100,
                                child: Column(
                                  children: [
                                    TextField(
                                      maxLength: 3,
                                      onChanged: (value) {},
                                      controller: kisiInputController,
                                      keyboardType: TextInputType.number,
                                      autofocus: true,
                                      decoration: InputDecoration(
                                        labelText: 'Aday Sayısını Giriniz',
                                        suffixIcon: IconButton(
                                          icon: Icon(Icons.clear),
                                          onPressed: () {
                                            kisiInputController.clear();
                                          },
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              actions: [
                                FlatButton(
                                  color: Colors.green,
                                  onPressed: () {
                                    Navigator.pop(context);
                                    kisiInputController.clear();
                                  },
                                  child: Text('İptal'),
                                ),
                                FlatButton(
                                  color: Colors.deepOrange,
                                  onPressed: () {
                                    if (int.parse(kisiInputController.text) >
                                        addList.length) {
                                      Navigator.pop(context);
                                      _snackbarKey.currentState
                                          .showSnackBar(SnackBar(
                                        backgroundColor: Colors.deepOrange,
                                        content: Row(
                                          children: [
                                            Text(
                                              '${addList.length} adaydan ${int.parse(kisiInputController.text)} aday seçilememektedir.',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        duration: Duration(seconds: 1),
                                      ));
                                      kisiInputController.clear();
                                    } else if (int.parse(
                                            kisiInputController.text) <=
                                        0) {
                                      Navigator.pop(context);
                                      _snackbarKey.currentState
                                          .showSnackBar(SnackBar(
                                        backgroundColor: Colors.deepOrange,
                                        content: Row(
                                          children: [
                                            Text(
                                              '${kisiInputController.text} aday seçilemez.',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        duration: Duration(seconds: 1),
                                      ));
                                      kisiInputController.clear();
                                    } else {
                                      selectedList = [];
                                      count =
                                          int.parse(kisiInputController.text);

                                      for (var i = 0; i < count; i++) {
                                        var aday = addList[
                                            _random.nextInt(addList.length)];
                                        setState(() {
                                          addList.remove(aday);
                                          selectedList.add(aday);
                                        });
                                      }
                                      setState(() {
                                        addList = [];
                                      });
                                      Navigator.pop(context);
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                SecondScreen()),
                                      );
                                    }
                                  },
                                  child: Text('Devam'),
                                )
                              ],
                            );
                          });
                    }
                  },
                )
              ],
            ),
      body: GestureDetector(
        onTap: () {
          _onBackPressed(context);
        },
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(
            children: [
              TextField(
                controller: inputController,
                maxLength: 12,
                decoration: InputDecoration(
                    suffixIcon: IconButton(
                      splashRadius: 25,
                      icon: Icon(Icons.delete),
                      onPressed: () {
                        setState(() {
                          inputController.clear();
                        });
                      },
                    ),
                    hintText: 'Aday',
                    labelText: 'Bir Aday Gir',
                    icon: Icon(Icons.add)),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  FlatButton(
                    color: Colors.green,
                    onPressed: () {
                      if (inputController.text.length == 0) {
                        _snackbarKey.currentState.showSnackBar(SnackBar(
                          backgroundColor: Colors.deepOrange,
                          content: Row(
                            children: [
                              Icon(Icons.person_outline),
                              Text(
                                'Aday Girilmedi.',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          duration: Duration(milliseconds: 500),
                        ));
                      } else {
                        if (addList.contains(inputController.text)) {
                          _snackbarKey.currentState.showSnackBar(SnackBar(
                            backgroundColor: Colors.deepOrange,
                            content: Row(
                              children: [
                                Text(
                                  'Bu Aday Zaten Var !',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            duration: Duration(milliseconds: 500),
                          ));
                        } else if (inputController.text.contains(',')) {
                          _snackbarKey.currentState.showSnackBar(SnackBar(
                            backgroundColor: Colors.deepOrange,
                            content: Row(
                              children: [
                                Text(
                                  ", koyulamaz.",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            duration: Duration(seconds: 1),
                          ));
                        } else {
                          addList.add(inputController.text);
                          setState(() {
                            addList = addList;
                          });
                        }
                      }
                      inputController.clear();
                    },
                    child: Text(
                      'Ekle',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                  ),
                  FlatButton(
                    color: Colors.red,
                    onPressed: () {
                      setState(() {
                        addList.clear();
                        _snackbarKey.currentState.showSnackBar(SnackBar(
                          backgroundColor: Colors.deepOrange,
                          content: Row(
                            children: [
                              Icon(Icons.check),
                              Text(
                                'İşlem Başarılı',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          duration: Duration(seconds: 1),
                        ));
                      });
                    },
                    child: Text(
                      'Her Şeyi Sil',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                  ),
                ],
              ),
              Divider(
                height: 20,
                indent: 500.0,
              ),
              addList.length == 0
                  ? Text(
                      'Henüz Eklenen Bir Aday Yok',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    )
                  : Text(
                      'Adaylar',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
              Expanded(
                child: ListView.separated(
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      // ignore: missing_required_param
                      return FlatButton(
                          child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '${index + 1}.  ' +
                                '${addList[index]}'.toUpperCase(),
                            style: TextStyle(
                                color: Colors.primaries[
                                    Random().nextInt(Colors.primaries.length)]),
                          ),
                          IconButton(
                            highlightColor: Colors.deepOrange,
                            splashRadius: 20,
                            iconSize: 20,
                            color: Colors.black,
                            icon: Icon(Icons.clear),
                            onPressed: () {
                              setState(() {
                                addList.remove(addList[index]);
                              });
                              _snackbarKey.currentState.showSnackBar(SnackBar(
                                backgroundColor: Colors.deepOrange,
                                content: Row(
                                  children: [
                                    Icon(Icons.delete),
                                    Text(
                                      'Aday Silindi.',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ],
                                ),
                                duration: Duration(milliseconds: 100),
                              ));
                            },
                          )
                        ],
                      ));
                    },
                    separatorBuilder: (context, index) => Divider(
                          height: 0,
                          indent: 500,
                        ),
                    itemCount: addList.length),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
