import 'dart:math';
import 'package:flutter/material.dart';
import 'main.dart';

class SecondScreen extends StatefulWidget {
  @override
  _SecondScreenState createState() => _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        title: Text('Sonuçlar'),
      ),
      floatingActionButton: FlatButton(
        color: Colors.deepOrange,
        onPressed: () {
          Navigator.pop(context);
        },
        child: Text(
          'Yeni Kura Çek',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.separated(
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  // ignore: missing_required_param
                  return FlatButton(
                    child: Text(
                      '${index + 1}.  ' +
                          '${selectedList[index]}'.toUpperCase(),
                      style: TextStyle(
                          color: Colors.primaries[
                              Random().nextInt(Colors.primaries.length)]),
                    ),
                  );
                },
                separatorBuilder: (context, index) => Divider(
                      height: 0,
                      indent: 500,
                    ),
                itemCount: selectedList.length),
          ),
        ],
      ),
    );
  }
}
