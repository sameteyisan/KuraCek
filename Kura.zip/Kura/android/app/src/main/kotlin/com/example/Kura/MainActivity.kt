package com.example.Kura

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
