package com.example.KuraCek

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
